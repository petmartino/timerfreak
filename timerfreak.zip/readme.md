# TODO

GLOBAL: SOUNDS FROM DATABASE

TIMER.HTML

FRONT END - Show a button to add to web home screen on mobile devices under link or instructions to adding this button on home screen. Also show instructions to add a bookmark (or a button if possible). (Update manifest if necesary)
GUI - Boton stop debe ser rojo
GUI - Fix con el desmadre del dark mode, 
GUI - Al principio hide timer info. 
GUI - Fix Loop controls, 
GUI - Do not show debug information
FUNC - Fix disableds, 
FUNC - Fix última alarma no suena
UX - Beep en interacciones dentro de timer. (High pitch play, all other low pitch play .01s) synthesized or mp3. 
GUI - DARK AND LIGHT MODE should be 1 html entity (character, utf symbol or emoji) to represent light and dark mode, so the button has the width of only one charachter.

INDEX.HTML
GUI - Always show the advanced controls, 
ANIMAR DELETE
AVOID ALERT
TRASH floated to the right, and only on selected timers. 
Method to prevent abuse.  

GLOBAL

CODE - Footer y ruta /about/ 
GUI - Templates with inherit, <titles>
DELETE UNUSED CODE, JAVASCRIPTS. SET DEFAULTS IN LET ME SET DEFAULTS IN APP.PY FOR DEFAULT COLOR, DEFAULT BAR HEIGHT - simplificar estilos, refactorar para limpieza, 
Avoid inline styles where possible.



# WHISHLIST 

- LOGO 
- Alarmas chidas y en base de datos.
- SAY SOMETHING
- AUTOCOMPACT-EXPAND y MAXIMIZE CURRENT (max current en DB)
- ZOOM CURRENT
- Pueden subir sonidos (y utilizo yo)
