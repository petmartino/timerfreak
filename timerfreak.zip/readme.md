# TODO

- Consistencia en msjs y validación
- Animación de crear formulario
- ELIMINAR formulario, y checlist de problemas
- Colorpicker overlay consistent

# FRONT END

- Advanced controls button
- Buttons for each digit
- buttons to links??


# WHISHLIST 

- SAY SOMETHING
-